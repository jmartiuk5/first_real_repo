from distutils.core import setup

setup(
	name		= 'Dict_Recorder',
	version		= '1.0.0',
	py_modules	= ['Dict_Recorder'],
	author		= 'James Martiuk',
	author_email	= 'jmartiuk5@gmail.com',
	url		= 'learningpython.com',
	description	= 'A simple printer of nested lists',
)
